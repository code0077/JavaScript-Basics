/*
    Boolean values javascript
*/

var str1 = "uttej";
var str2 = "adiraju";

console.log(str1 > str2);

// Important
console.log(NaN == NaN);

var value = 5;
var notNumber = "hello world";

console.log(isNaN(value));
console.log(isNaN(notNumber));