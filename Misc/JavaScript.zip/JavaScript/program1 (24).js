/*
    Prevent automatic type conversions javascript
    Use === operator
    value is precisely equal to other or not

    only use == if you are sure that types on both sides will be same
*/


console.log(false === 0);
console.log(null === 0);
console.log(false === " ");