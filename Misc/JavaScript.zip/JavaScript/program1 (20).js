var result = ` Half of 100 is ${100/2} `;
console.log(result);
console.log( ` Half of 10000 is ${10000/2} `);